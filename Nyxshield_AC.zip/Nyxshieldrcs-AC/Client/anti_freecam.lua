CreateThread(function()
    while true do
        Wait(3000)

        if not IsGameplayCamRendering() then
            addFlag("Freecam", 3)
        end
    end
end)