CreateThread(function()
    while true do
        Wait(5000)

        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)
        local ammo = GetAmmoInPedWeapon(ped, weapon)

        if ammo > 250 then
            addFlag("InfiniteAmmo", 3)
        end
    end
end)