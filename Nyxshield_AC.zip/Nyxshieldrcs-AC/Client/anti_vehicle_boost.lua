CreateThread(function()
    while true do
        Wait(2000)

        local veh = GetVehiclePedIsIn(PlayerPedId(), false)

        if veh ~= 0 then
            if GetEntitySpeed(veh) > 100 then
                addFlag("VehicleBoost", 2)
            end
        end
    end
end)