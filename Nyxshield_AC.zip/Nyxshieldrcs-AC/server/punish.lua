function PunishPlayer(src, reason)
    SendLog("🚫 Player "..src.." banned: "..reason)
    DropPlayer(src, reason)
end