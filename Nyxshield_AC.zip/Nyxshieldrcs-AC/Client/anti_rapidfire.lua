local lastShot = 0

CreateThread(function()
    while true do
        Wait(0)

        if IsPedShooting(PlayerPedId()) then
            local now = GetGameTimer()

            if now - lastShot < 60 then
                addFlag("RapidFire", 2)
            end

            lastShot = now
        end
    end
end)