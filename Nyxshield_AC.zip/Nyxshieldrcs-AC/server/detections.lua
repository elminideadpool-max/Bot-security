local flags = {}

RegisterNetEvent("nyx:flag")
AddEventHandler("nyx:flag", function(token, reason)
    local src = source

    if not ValidateToken(src, token) then
        DropPlayer(src, "Bypass detected")
        return
    end

    flags[src] = (flags[src] or 0) + 1

    print("[NyxShield] " .. GetPlayerName(src) .. " -> " .. reason .. " ("..flags[src]..")")

    if flags[src] >= 7 then
        DropPlayer(src, "NyxShield: Cheating detected")
    end
end)