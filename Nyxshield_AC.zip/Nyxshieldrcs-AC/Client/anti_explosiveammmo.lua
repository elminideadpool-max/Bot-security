AddEventHandler("gameEventTriggered", function(name, args)
    if name == "CEventNetworkEntityDamage" then
        local weapon = args[7]

        if weapon == `WEAPON_EXPLOSION` then
            addFlag("ExplosiveAmmo", 3)
        end
    end
end)