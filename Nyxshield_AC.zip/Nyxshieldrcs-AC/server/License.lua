local licenseKey = "TU_LICENSE"
local hwid = GetConvar("sv_hostname", "unknown")

PerformHttpRequest("http://localhost:3000/validate", function(err, text)
    local data = json.decode(text)

    if not data or not data.valid then
        print("❌ License invalid")
        os.exit()
    else
        print("✅ License valid")
    end
end, "POST", json.encode({
    key = licenseKey,
    hwid = hwid
}), {["Content-Type"] = "application/json"})