local scores = {}

function AddScore(src, reason, amount)
    scores[src] = (scores[src] or 0) + amount

    print("[AC] "..src.." -> "..reason.." ("..scores[src]..")")

    if scores[src] >= Config.ScoreBan then
        BanPlayer(src, reason)
    end
end

-- 🔻 DECAY (evita falsos positivos)
CreateThread(function()
    while true do
        Wait(60000)
        for k,v in pairs(scores) do
            scores[k] = math.max(v - Config.ScoreDecay, 0)
        end
    end
end)