CreateThread(function()
    while true do
        Wait(3000)

        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        TriggerServerEvent(nyxweaponCheck, weapon)
    end
end)