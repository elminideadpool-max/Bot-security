Config = {}

Config.License = "NYX-CBA435-1A2B"
Config.API = "http://localhost:3000/license"

Config.MaxSpeed = 9.0

Config.BlacklistedWeapons = {
    "WEAPON_RPG",
    "WEAPON_MINIGUN"
}