CreateThread(function()
    while true do
        Wait(3000)

        local ped = PlayerPedId()
        local health = GetEntityHealth(ped)

        if health > 200 then
            addFlag("Godmode", 4)
        end
    end
end)