CreateThread(function()
    while true do
        Wait(3000)

        local weapon = GetSelectedPedWeapon(PlayerPedId())

        for _, w in pairs(Config.BlacklistedWeapons) do
            if weapon == GetHashKey(w) then
                TriggerServerEvent("nyx:flag", GetToken(), "Weapon: "..w)
            end
        end
    end
end)