CreateThread(function()
    while true do
        Wait(3000)

        if not IsEntityVisible(PlayerPedId()) then
            addFlag("Invisible", 2)
        end
    end
end)