local lastCoords = nil

CreateThread(function()
    while true do
        Wait(2000)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        if lastCoords then
            local dist = #(coords - lastCoords)

            if dist > 120 then
                addFlag("Teleport", 3)
            end
        end

        lastCoords = coords
    end
end)