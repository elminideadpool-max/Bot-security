local lastHeading = nil
local suspiciousAim = 0

CreateThread(function()
    while true do
        Wait(500)

        local ped = PlayerPedId()

        if IsPedShooting(ped) then
            local heading = GetEntityHeading(ped)

            if lastHeading then
                local diff = math.abs(heading - lastHeading)

                if diff > 20.0 and diff < 25.0 then
                    suspiciousAim = suspiciousAim + 1
                end
            end

            lastHeading = heading

            if suspiciousAim >= 5 then
                TriggerServerEvent("nyx:flag", GetToken(), "Aimbot Suspected")
                suspiciousAim = 0
            end
        end
    end
end)