local eventCount = {}

RegisterNetEvent("nyx:testEvent", function()
    local src = source

    eventCount[src] = (eventCount[src] or 0) + 1

    if eventCount[src] > Config.MaxEventsPerSecond then
        AddScore(src, "Event Spam", 20)
    end
end)

CreateThread(function()
    while true do
        Wait(1000)
        eventCount = {}
    end
end)