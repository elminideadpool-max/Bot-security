RegisterNetEvent("nyx:secureEvent")
AddEventHandler("nyx:secureEvent", function(token)
    local src = source

    if not ValidateToken(src, token) then
        DropPlayer(src, "Unauthorized trigger")
    end
end)