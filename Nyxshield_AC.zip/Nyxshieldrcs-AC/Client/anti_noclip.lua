CreateThread(function()
    while true do
        Wait(2000)

        local ped = PlayerPedId()

        if not IsPedInAnyVehicle(ped, false) then
            if GetEntityCollisionDisabled(ped) then
                addFlag("Noclip", 3)
            end
        end
    end
end)