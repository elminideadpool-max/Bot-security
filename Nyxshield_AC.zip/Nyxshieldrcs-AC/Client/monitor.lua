CreateThread(function()
    while true do
        Wait(1000)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        -- movimiento
        TriggerServerEvent("nyx:movement", coords)

        -- disparo
        if IsPedShooting(ped) then
            local headshot = false

            local _, hit, endCoords, entity = GetEntityPlayerIsFreeAimingAt(PlayerId())

            if hit and entity and IsEntityAPed(entity) then
                local bone = GetPedLastDamageBone(entity)
                if bone == 31086 then -- head
                    headshot = true
                end
            end

            TriggerServerEvent("nyx:shotFired", headshot)
        end

        -- eventos seguros
        TriggerServerEvent("nyx:secureEvent")
    end
end)