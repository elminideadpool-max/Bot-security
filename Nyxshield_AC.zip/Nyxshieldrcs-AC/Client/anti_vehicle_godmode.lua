CreateThread(function()
    while true do
        Wait(3000)

        local veh = GetVehiclePedIsIn(PlayerPedId(), false)

        if veh ~= 0 then
            if GetEntityHealth(veh) > 1000 then
                addFlag("VehicleGodmode", 3)
            end
        end
    end
end)