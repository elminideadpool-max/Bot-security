local token = nil

RegisterNetEvent("nyx:receiveToken")
AddEventHandler("nyx:receiveToken", function(t)
    token = t
end)

CreateThread(function()
    TriggerServerEvent("nyx:requestToken")
end)

function GetToken()
    return token
end