CreateThread(function()
    while true do
        Wait(3000)

        if NetworkIsInSpectatorMode() then
            addFlag("Spectate", 3)
        end
    end
end)