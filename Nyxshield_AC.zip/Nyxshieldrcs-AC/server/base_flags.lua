local flags = 0

function addFlag(reason, amount)
    flags = flags + amount
    print("[NYX]", reason, "TOTAL:", flags)

    if flags >= 10 then
        TriggerServerEvent("nyx:ban", reason)
    elseif flags >= 6 then
        TriggerServerEvent("nyx:kick", reason)
    end
end

-- decay (reduce flags)
CreateThread(function()
    while true do
        Wait(10000)
        if flags > 0 then
            flags = flags - 1
        end
    end
end)