CreateThread(function()
    while true do
        Wait(1500)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local speed = GetEntitySpeed(ped)
        local inVehicle = IsPedInAnyVehicle(ped, false)

        -- SPEED
        if speed > Config.MaxSpeed then
            TriggerServerEvent("nyx:flag", GetToken(), "Speed Hack")
        end

        -- NOCLIP
        local foundGround, groundZ = GetGroundZFor_3dCoord(coords.x, coords.y, coords.z, 0)

        if foundGround then
            local dist = coords.z - groundZ

            if dist > 5.0 and speed > 2.0 and not inVehicle then
                if not IsPedFalling(ped) and not IsPedJumping(ped) then
                    TriggerServerEvent("nyx:flag", GetToken(), "Noclip")
                end
            end
        end

        -- INVISIBLE
        if not IsEntityVisible(ped) then
            TriggerServerEvent("nyx:flag", GetToken(), "Invisible")
        end
    end
end)