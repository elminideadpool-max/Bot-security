function SendLog(msg)
    PerformHttpRequest(Config.Webhook, function() end, "POST", json.encode({
        content = msg
    }), { ["Content-Type"] = "application/json" })
end