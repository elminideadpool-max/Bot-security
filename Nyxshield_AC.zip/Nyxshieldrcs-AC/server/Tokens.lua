local playerTokens = {}

RegisterNetEvent("nyx:requestToken")
AddEventHandler("nyx:requestToken", function()
    local src = source
    local token = tostring(math.random(100000,999999))

    playerTokens[src] = token

    TriggerClientEvent("nyx:receiveToken", src, token)
end)

function ValidateToken(src, token)
    return playerTokens[src] == token
end