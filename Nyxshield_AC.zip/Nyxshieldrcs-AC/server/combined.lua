local lastCoords = nil
local lastShot = 0

-- 1️⃣ TELEPORT + SPEED + NOCLIP
CreateThread(function()
    while true do
        Wait(2000)

        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local speed = GetEntitySpeed(ped)

        if lastCoords then
            if #(coords - lastCoords) > 100 then addFlag("Teleport", 3) end
            if speed > 10.0 then addFlag("SpeedHack", 2) end
            if GetEntityCollisionDisabled(ped) then addFlag("NoClip", 3) end
        end

        lastCoords = coords
    end
end)

-- 2️⃣ AIMBOT + RAPID FIRE
CreateThread(function()
    while true do
        Wait(0)

        if IsPedShooting(PlayerPedId()) then
            local now = GetGameTimer()

            if now - lastShot < 50 then addFlag("RapidFire", 2) end
            lastShot = now

            if IsPlayerFreeAiming(PlayerId()) then
                addFlag("Aimbot", 1)
            end
        end
    end
end)

-- 3️⃣ GODMODE + HEALTH
CreateThread(function()
    while true do
        Wait(3000)
        local health = GetEntityHealth(PlayerPedId())

        if health > 200 then addFlag("Godmode", 4) end
        if health > 150 then addFlag("HighHealth", 1) end
    end
end)

-- 4️⃣ VEHICLE COMBO
CreateThread(function()
    while true do
        Wait(3000)
        local veh = GetVehiclePedIsIn(PlayerPedId(), false)

        if veh ~= 0 then
            if GetEntityHealth(veh) > 1000 then addFlag("VehGodmode", 3) end
            if GetEntitySpeed(veh) > 100 then addFlag("VehBoost", 2) end
        end
    end
end)

-- 5️⃣ FREECAM + INVISIBLE + SPECTATE
CreateThread(function()
    while true do
        Wait(3000)

        if not IsGameplayCamRendering() then addFlag("Freecam", 3) end
        if not IsEntityVisible(PlayerPedId()) then addFlag("Invisible", 2) end
        if NetworkIsInSpectatorMode() then addFlag("Spectate", 3) end
    end
end)

-- 6️⃣ AMMO + DAMAGE
CreateThread(function()
    while true do
        Wait(5000)

        local ped = PlayerPedId()
        local weapon = GetSelectedPedWeapon(ped)

        if GetAmmoInPedWeapon(ped, weapon) > 250 then
            addFlag("InfiniteAmmo", 3)
        end

        if GetWeaponDamage(weapon) > 100 then
            addFlag("DamageBoost", 3)
        end
    end
end)