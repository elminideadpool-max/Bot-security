CreateThread(function()
    while true do
        Wait(2000)

        local speed = GetEntitySpeed(PlayerPedId())

        if speed > 10.0 then
            addFlag("SpeedHack", 2)
        end
    end
end)