local lastVehCoords = nil

CreateThread(function()
    while true do
        Wait(2000)

        local veh = GetVehiclePedIsIn(PlayerPedId(), false)

        if veh ~= 0 then
            local coords = GetEntityCoords(veh)

            if lastVehCoords then
                if #(coords - lastVehCoords) > 150 then
                    addFlag("VehicleTeleport", 3)
                end
            end

            lastVehCoords = coords
        end
    end
end)